function Assignment(title, description, submissionDate, oralMark, totalMark){
    this.title = title;
    this.description = description;
    this.submissionDate = submissionDate;
    this.oralMark = oralMark;
    this.totalMark = totalMark;
}

function assignmentToString(assignment){
    return (`Assignment Title:         ${assignment.title} 
             Assignment Description:   ${assignment.description} 
             Submission Date:          ${assignment.submissionDate} 
             Oral Mark:                ${assignment.oralMark} 
             Total Mark:               ${assignment.totalMark}`)
}

let assignments=[];
    let assignmentTitle=document.getElementById("title");
    let assignmentDescription=document.getElementById("description");
    let assignmentSubmissionDate=document.getElementById("submissionDate");
    let assignmentOralMark=document.getElementById("oralMark");
    let assignmentTotalmark=document.getElementById("totalMark");
    let btnSubmit=document.getElementById('submit');
    btnSubmit.addEventListener("click",submit);

    let btnReset=document.getElementById('reset');
    btnReset.addEventListener('click', reset);

    let btnUpdate=document.getElementById('update');
    btnUpdate.addEventListener('click',update);

    let divAssignments=document.getElementById("assignments");

    function submit(event){
        event.preventDefault();
        let myAssignment=new Assignment(assignmentTitle.value, assignmentDescription.value, assignmentSubmissionDate.value, assignmentOralMark.value ,assignmentTotalmark.value);
        assignments.push(myAssignment);
        let btnEdit=document.createElement('button');
        btnEdit.textContent='Edit';
        btnEdit.assignmentIndex=assignments.length-1;
        btnEdit.addEventListener('click', edit);
        createParagraphElement(myAssignment,btnEdit);
        btnReset.click();
        console.log(assignments);
    }

    function reset(event){
        btnSubmit.textContent="&#10133;     Add Form";
    }

    function edit(event){
        assignmentTitle.value=assignments[this.assignmentIndex].title;
        assignmentDescription.value=assignments[this.assignmentIndex].description;
        assignmentSubmissionDate.value=assignments[this.assignmentIndex].submissionDate;
        assignmentOralMark.value=assignments[this.assignmentIndex].oralMark;
        assignmentTotalmark.value=assignments[this.assignmentIndex].totalMark;
        btnSubmit.hidden=true;
        btnUpdate.hidden=false;
        btnUpdate.assignmentIndex=this.assignmentIndex;
    }

    function update(event){
        event.preventDefault();
        assignments[this.assignmentIndex]=new Assignment(assignmentTitle.value, assignmentDescription.value, assignmentSubmissionDate.value, assignmentOralMark.value ,assignmentTotalmark.value);
        divAssignments.innerHTML="";
        for(let i=0; i< assignments.length; i++){
            let btnEdit=document.createElement('button');
            btnEdit.textContent='Edit';
            btnEdit.assignmentIndex=i;
            btnEdit.addEventListener('click', edit);
            createParagraphElement(assignments[i], btnEdit)
        }
        btnUpdate.hidden=true;
        btnSubmit.hidden=false;
        btnReset.click();
    }

    function createParagraphElement(assignment,editButton){
        let paragraph=document.createElement('p');
        paragraph.innerText=assignmentToString(assignment);
        let spanSpace=document.createElement('span');
        spanSpace.innerHTML='&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
        paragraph.append(spanSpace,editButton);
        divAssignments.append(paragraph);
    }