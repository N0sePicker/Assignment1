function Trainer(firstName, lastName, teaching, email){
    this.firstName = firstName;
    this.lastName = lastName;
    this.teaching = teaching;
    this.email = email;
}

function trainerToString(trainer){
    return (`First Name:     ${trainer.firstName} 
             Last Name:      ${trainer.lastName} 
             Teaching:       ${trainer.teaching} 
             Email :         ${trainer.email}`)
}

let trainers=[];
    let trainerFirstName=document.getElementById("firstName");
    let trainerLastName=document.getElementById("lastName");
    let trainerTeaching=document.getElementById("teaching");
    let trainerEmail=document.getElementById("email");
    let btnSubmit=document.getElementById('submit');
    btnSubmit.addEventListener("click",submit);

    let btnReset=document.getElementById('reset');
    btnReset.addEventListener('click', reset);

    let btnUpdate=document.getElementById('update');
    btnUpdate.addEventListener('click',update);

    let divTrainers=document.getElementById("trainers");

    function submit(event){
        event.preventDefault();
        let myTrainer=new Trainer(trainerFirstName.value, trainerLastName.value, trainerTeaching.value ,trainerEmail.value);
        trainers.push(myTrainer);
        let btnEdit=document.createElement('button');
        btnEdit.textContent='Edit';
        btnEdit.trainerIndex=trainers.length-1;
        btnEdit.addEventListener('click', edit);
        createParagraphElement(myTrainer,btnEdit);
        btnReset.click();
        console.log(trainers);
    }

    function reset(event){
        btnSubmit.textContent="&#10133;     Add Form";
    }

    function edit(event){
        trainerFirstName.value=trainers[this.trainerIndex].firstName;
        trainerLastName.value=trainers[this.trainerIndex].lastName;
        trainerTeaching.value=trainers[this.trainerIndex].teaching;
        trainerEmail.value=trainers[this.trainerIndex].email;
        btnSubmit.hidden=true;
        btnUpdate.hidden=false;
        btnUpdate.trainerIndex=this.trainerIndex;
    }

    function update(event){
        event.preventDefault();
        trainers[this.trainerIndex]=new Trainer(trainerFirstName.value, trainerLastName.value, trainerTeaching.value, trainerEmail.value);
        divTrainers.innerHTML="";
        for(let i=0; i< trainers.length; i++){
            let btnEdit=document.createElement('button');
            btnEdit.textContent='Edit';
            btnEdit.trainerIndex=i;
            btnEdit.addEventListener('click', edit);
            createParagraphElement(trainers[i], btnEdit)
        }
        btnUpdate.hidden=true;
        btnSubmit.hidden=false;
        btnReset.click();
    }

    function createParagraphElement(trainer,editButton){
        let paragraph=document.createElement('p');
        paragraph.innerText=trainerToString(trainer);
        let spanSpace=document.createElement('span');
        spanSpace.innerHTML='&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
        paragraph.append(spanSpace,editButton);
        divTrainers.append(paragraph);
    }