function AssignmentPSCourse(studentName, title){
    this.studentName = studentName;
    this.title = title;
}

function assignmentToString(assignment){
    return (`First Name:            ${assignment.studentName} 
             Assignment Title:      ${assignment.title}`)
}

let assignments=[];
    let assignmentStudentName=document.getElementById("studentName");
    let assignmentTitle=document.getElementById("title");
    let btnSubmit=document.getElementById('submit');
    btnSubmit.addEventListener("click",submit);

    let btnReset=document.getElementById('reset');
    btnReset.addEventListener('click', reset);

    let btnUpdate=document.getElementById('update');
    btnUpdate.addEventListener('click',update);

    let divAssignments=document.getElementById("assignments");

    function submit(event){
        event.preventDefault();
        let myAssignment=new AssignmentPSCourse(assignmentStudentName.value, assignmentTitle.value);
        assignments.push(myAssignment);
        let btnEdit=document.createElement('button');
        btnEdit.textContent='Edit';
        btnEdit.assignmentIndex=assignments.length-1;
        btnEdit.addEventListener('click', edit);
        createParagraphElement(myAssignment,btnEdit);
        btnReset.click();
        console.log(assignments);
    }

    function reset(event){
        btnSubmit.textContent="&#10133;     Add Form";
    }

    function edit(event){
        assignmentStudentName.value=assignments[this.assignmentIndex].studentName;
        assignmentTitle.value=assignments[this.assignmentIndex].title;
        btnUpdate.hidden=false;
        btnUpdate.assignmentIndex=this.assignmentIndex;
    }

    function update(event){
        event.preventDefault();
        assignments[this.assignmentIndex]=new AssignmentPSCourse(assignmentStudentName.value, assignmentTitle.value);
        divAssignments.innerHTML="";
        for(let i=0; i< assignments.length; i++){
            let btnEdit=document.createElement('button');
            btnEdit.textContent='Edit';
            btnEdit.assignmentIndex=i;
            btnEdit.addEventListener('click', edit);
            createParagraphElement(assignments[i], btnEdit)
        }
        btnUpdate.hidden=true;
        btnSubmit.hidden=false;
        btnReset.click();
    }

    function createParagraphElement(assignment,editButton){
        let paragraph=document.createElement('p');
        paragraph.innerText=assignmentToString(assignment);
        let spanSpace=document.createElement('span');
        spanSpace.innerHTML='&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
        paragraph.append(spanSpace,editButton);
        divAssignments.append(paragraph);
    }