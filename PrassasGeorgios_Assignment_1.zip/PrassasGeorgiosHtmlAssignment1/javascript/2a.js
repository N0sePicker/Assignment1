
function TrainerPerCourse(teachers,stream){
    this.teachers = teachers;
    this.stream = stream;
}

function trainerToString(trainer){
    return (`Trainers Name:     ${trainer.teachers} 
             Teaching:          ${trainer.stream} `)
}

let trainers=[];
    let Teachers=document.getElementById("teachers");
    let Stream=document.getElementById("stream");
    let btnSubmit=document.getElementById('submit');
    btnSubmit.addEventListener("click",submit);

    let btnReset=document.getElementById('reset');
    btnReset.addEventListener('click', reset);

    let btnUpdate=document.getElementById('update');
    btnUpdate.addEventListener('click',update);

    let divTrainers=document.getElementById("trainers");

    function submit(event){
        event.preventDefault();
        let myTrainer=new TrainerPerCourse(Teachers.value, Stream.value);
        trainers.push(myTrainer);
        let btnEdit=document.createElement('button');
        btnEdit.textContent='Edit';
        btnEdit.trainerIndex=trainers.length-1;
        btnEdit.addEventListener('click', edit);
        createParagraphElement(myTrainer,btnEdit);
        btnReset.click();
        console.log(trainers);
    }

    function reset(event){
        btnSubmit.textContent="&#10133;     Add Form";
    }

    function edit(event){
        Teachers.value=trainers[this.trainerIndex].teachers;
        Stream.value=trainers[this.trainerIndex].stream;
        btnSubmit.hidden=true;
        btnUpdate.hidden=false;
        btnUpdate.trainerIndex=this.trainerIndex;
    }

    function update(event){
        event.preventDefault();
        trainers[this.trainerIndex]=new TrainerPerCourse(Teachers.value, Stream.value );
        divTrainers.innerHTML="";
        for(let i=0; i< trainers.length; i++){
            let btnEdit=document.createElement('button');
            btnEdit.textContent='Edit';
            btnEdit.trainerIndex=i;
            btnEdit.addEventListener('click', edit);
            createParagraphElement(trainers[i], btnEdit)
        }
        btnUpdate.hidden=true;
        btnSubmit.hidden=false;
        btnReset.click();
    }

    function createParagraphElement(trainer,editButton){
        let paragraph=document.createElement('p');
        paragraph.innerText=trainerToString(trainer);
        let spanSpace=document.createElement('span');
        spanSpace.innerHTML='&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
        paragraph.append(spanSpace,editButton);
        divTrainers.append(paragraph);
    }