
function StudentPerCourse(studentName, stream){
    this.studentName = studentName;
    this.stream = stream;
}

function studentToString(student){
    return (`Student Name:     ${student.studentName} 
             Stream:           ${student.stream}`)
}

let students=[];
    let studentStudentName=document.getElementById("studentName");
    let studentStream=document.getElementById("stream");
    let btnSubmit=document.getElementById('submit');
    btnSubmit.addEventListener("click",submit);

    let btnReset=document.getElementById('reset');
    btnReset.addEventListener('click', reset);

    let btnUpdate=document.getElementById('update');
    btnUpdate.addEventListener('click',update);

    let divStudents=document.getElementById("students");

    function submit(event){
        event.preventDefault();
        let myStudent=new StudentPerCourse(studentStudentName.value, studentStream.value);
        students.push(myStudent);
        let btnEdit=document.createElement('button');
        btnEdit.textContent='Edit';
        btnEdit.studentIndex=students.length-1;
        btnEdit.addEventListener('click', edit);
        createParagraphElement(myStudent,btnEdit);
        btnReset.click();
        console.log(students);
    }

    function reset(event){
        btnSubmit.textContent="&#10133;     Add Form";
    }

    function edit(event){
        studentStudentName.value=students[this.studentIndex].studentName;
        studentStream.value=students[this.studentIndex].stream;
        btnSubmit.hidden=true;
        btnUpdate.hidden=false;
        btnUpdate.studentIndex=this.studentIndex;
    }

    function update(event){
        event.preventDefault();
        students[this.studentIndex]=new StudentPerCourse(studentStudentName.value, studentStream.value);
        divStudents.innerHTML="";
        for(let i=0; i< students.length; i++){
            let btnEdit=document.createElement('button');
            btnEdit.textContent='Edit';
            btnEdit.studentIndex=i;
            btnEdit.addEventListener('click', edit);
            createParagraphElement(students[i], btnEdit)
        }
        btnUpdate.hidden=true;
        btnSubmit.hidden=false;
        btnReset.click();
    }

    function createParagraphElement(student,editButton){
        let paragraph=document.createElement('p');
        paragraph.innerText=studentToString(student);
        let spanSpace=document.createElement('span');
        spanSpace.innerHTML='&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
        paragraph.append(spanSpace,editButton);
        divStudents.append(paragraph);
    }


