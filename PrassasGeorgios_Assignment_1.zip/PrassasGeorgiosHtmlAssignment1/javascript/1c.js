function Student(firstName, lastName, birthDay, tuitionFees, email){
    this.firstName = firstName;
    this.lastName = lastName;
    this.birthDay = birthDay;
    this.tuitionFees = tuitionFees;
    this.email = email;
}

function studentToString(student){
    return (`First Name:     ${student.firstName} 
             Last Name:      ${student.lastName} 
             Date of Birth:  ${student.birthDay} 
             Tuition Fees:   ${student.tuitionFees} €
             Email :         ${student.email}`)
}

let students=[];
    let studentFirstName=document.getElementById("firstName");
    let studentLastName=document.getElementById("lastName");
    let studentBirthDay=document.getElementById("birthDay");
    let studentTuitionFees=document.getElementById("tuitionFees");
    let studentEmail=document.getElementById("email");
    let btnSubmit=document.getElementById('submit');
    btnSubmit.addEventListener("click",submit);

    let btnReset=document.getElementById('reset');
    btnReset.addEventListener('click', reset);

    let btnUpdate=document.getElementById('update');
    btnUpdate.addEventListener('click',update);

    let divStudents=document.getElementById("students");

    function submit(event){
        event.preventDefault();
        let myStudent=new Student(studentFirstName.value, studentLastName.value, studentBirthDay.value, studentTuitionFees.value ,studentEmail.value);
        students.push(myStudent);
        let btnEdit=document.createElement('button');
        btnEdit.textContent='Edit';
        btnEdit.studentIndex=students.length-1;
        btnEdit.addEventListener('click', edit);
        createParagraphElement(myStudent,btnEdit);
        btnReset.click();
        console.log(students);
    }

    function reset(event){
        btnSubmit.textContent="&#10133;     Add Form";
    }

    function edit(event){
        studentFirstName.value=students[this.studentIndex].firstName;
        studentLastName.value=students[this.studentIndex].lastName;
        studentBirthDay.value=students[this.studentIndex].birthDay;
        studentTuitionFees.value=students[this.studentIndex].tuitionFees;
        studentEmail.value=students[this.studentIndex].email;
        btnSubmit.hidden=true;
        btnUpdate.hidden=false;
        btnUpdate.studentIndex=this.studentIndex;
    }

    function update(event){
        event.preventDefault();
        students[this.studentIndex]=new Student(studentFirstName.value, studentLastName.value, studentBirthDay.value, studentTuitionFees.value ,studentEmail.value);
        divStudents.innerHTML="";
        for(let i=0; i< students.length; i++){
            let btnEdit=document.createElement('button');
            btnEdit.textContent='Edit';
            btnEdit.studentIndex=i;
            btnEdit.addEventListener('click', edit);
            createParagraphElement(students[i], btnEdit)
        }
        btnUpdate.hidden=true;
        btnSubmit.hidden=false;
        btnReset.click();
    }

    function createParagraphElement(student,editButton){
        let paragraph=document.createElement('p');
        paragraph.innerText=studentToString(student);
        let spanSpace=document.createElement('span');
        spanSpace.innerHTML='&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
        paragraph.append(spanSpace,editButton);
        divStudents.append(paragraph);
    }