function Courses(title, stream, type, startDate, endDate){
    this.title = title;
    this.stream = stream;
    this.type = type;
    this.startDate = startDate;
    this.endDate = endDate;
}

function courseToString(courses){
    return (`Title:         ${courses.title} 
             Stream:        ${courses.stream} 
             Type:          ${courses.type} 
             Start Date:    ${courses.startDate} 
             End Date:      ${courses.endDate}`)
}

let courses=[];
    let coursesTitle=document.getElementById("title");
    let coursesStream=document.getElementById("stream");
    let coursesType=document.getElementById("type");
    let coursesStartDate=document.getElementById("startDate");
    let coursesEndDate=document.getElementById("endDate");
    let btnSubmit=document.getElementById('submit');
    btnSubmit.addEventListener("click",submit);

    let btnReset=document.getElementById('reset');
    btnReset.addEventListener('click', reset);

    let btnUpdate=document.getElementById('update');
    btnUpdate.addEventListener('click',update);

    let divCourses=document.getElementById("courses");

    function submit(event){
        event.preventDefault();
        let myCourse=new Courses(coursesTitle.value, coursesStream.value, coursesType.value, coursesStartDate.value ,coursesEndDate.value);
        courses.push(myCourse);
        let btnEdit=document.createElement('button');
        btnEdit.textContent='Edit';
        btnEdit.courseIndex=courses.length-1;
        btnEdit.addEventListener('click', edit);
        createParagraphElement(myCourse,btnEdit);
        btnReset.click();
        console.log(courses);
    }

    function reset(event){
        btnSubmit.textContent="&#10133;     Add Form";
    }

    function edit(event){
        coursesTitle.value=courses[this.courseIndex].title;
        coursesStream.value=courses[this.courseIndex].stream;
        coursesType.value=courses[this.courseIndex].type;
        coursesStartDate.value=courses[this.courseIndex].startDate;
        coursesEndDate.value=courses[this.courseIndex].endDate;
        btnSubmit.hidden=true;
        btnUpdate.hidden=false;
        btnUpdate.courseIndex=this.courseIndex;
    }

    function update(event){
        event.preventDefault();
        courses[this.courseIndex]=new Courses(coursesTitle.value, coursesStream.value, coursesType.value, coursesStartDate.value, coursesEndDate.value);
        divCourses.innerHTML="";
        for(let i=0; i< courses.length; i++){
            let btnEdit=document.createElement('button');
            btnEdit.textContent='Edit';
            btnEdit.courseIndex=i;
            btnEdit.addEventListener('click', edit);
            createParagraphElement(courses[i], btnEdit)
        }
        btnUpdate.hidden=true;
        btnSubmit.hidden=false;
        btnReset.click();
    }

    function createParagraphElement(course,editButton){
        let paragraph=document.createElement('p');
        paragraph.innerText=courseToString(course);
        let spanSpace=document.createElement('span');
        spanSpace.innerHTML='&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
        paragraph.append(spanSpace,editButton);
        divCourses.append(paragraph);
    }